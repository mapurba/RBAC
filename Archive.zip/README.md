# abacSpringSecurity
Attribute-Based Access Control with Spring Security

For more details, check [The DZone article](https://dzone.com/articles/simple-attribute-based-access-control-with-spring)

All REST requests with sample data are in abacSpringSecurity.postman_collection.json, you can import it into Postman chrome extension.

## How to Build
```shel
mvn clean install
```
# Sample Application
## How to deploy and run
- Copy *sample-Resource-tracker/target/sample-Resource-tracker.war* to your tomcat *webapps* folder
-  Start tomcat

## How to test
- Add new Tasks using **POST /sample-Resource-tracker/Taskss/**
- Assign PM to the Tasks using **PUT /sample-Resource-tracker/Taskss/{Tasks_id}/pm/**
- Add users to the Tasks using **POST /sample-Resource-tracker/Taskss/{Tasks_id}/users/**
- Add Resources to the Tasks using **POST /sample-Resource-tracker/Taskss/{Tasks_id}/Resources/**
- Assign Resources to users using **PUT /sample-Resource-tracker/Taskss/{Tasks_id}/Resources/{Resource_id}/assignee**
- Update Resource's status **PUT /sample-Resource-tracker/Taskss/{Tasks_id}/Resources/{Resource_id}/status**

## User Authentication
The sample application uses HTTP Basic Authentication and blow are the users that can be used:
- admin/password	
- pm1/password
- pm2/password
- dev1/password
- dev2/password
- test1/password
- test2/password

All users can be found and modified in **assig.apurba.rar.config.InMemoryUserDetailsService** class.
