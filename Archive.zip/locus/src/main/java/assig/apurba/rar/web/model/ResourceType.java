package assig.apurba.rar.web.model;

public enum ResourceType {
	LAPTOP,CAR,SALARY
}
