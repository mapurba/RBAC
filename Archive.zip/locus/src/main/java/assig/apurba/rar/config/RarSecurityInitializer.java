package assig.apurba.rar.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class RarSecurityInitializer extends AbstractSecurityWebApplicationInitializer {
}
