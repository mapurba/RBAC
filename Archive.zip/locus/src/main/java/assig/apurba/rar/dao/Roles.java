package assig.apurba.rar.dao;

public enum Roles {
	ADMIN, PM, DEVELOPER, TESTER
}
