package assig.apurba.rar.dao;



public abstract class Entity {
    
    public Long entityId;
    public abstract Long getEntityId();
    public abstract void setEntityId(Long id);


}