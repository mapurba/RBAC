package assig.apurba.rar.web.model;

public enum ResourceStatus {
	NEW, ASSIGNED, BLOCKED
}
