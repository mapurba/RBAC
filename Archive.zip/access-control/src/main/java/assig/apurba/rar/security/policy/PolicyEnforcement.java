package assig.apurba.rar.security.policy;

import java.util.List;

public interface PolicyEnforcement {

	boolean check(Object subject, Object resource, Object action, Object environment);

}